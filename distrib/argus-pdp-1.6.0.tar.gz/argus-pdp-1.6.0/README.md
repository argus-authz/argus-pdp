# Argus PDP server

The Argus Authorization Service renders XACML authorization decisions for distributed services, based on policies. The Argus PDP server is responsible for the evaluation of the XACML authorization request against the XACML policies.
